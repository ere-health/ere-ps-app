Erkl�rung zur Nutzung dieses Archives

Diese Erkl�rung erstreckt sich auf die Nutzung dieses Archives sowie alle nachfolgenden Versionen. 
Mit dem Entpacken der Datei nimmt das Softwarehaus die folgende Information zur Kenntnis:

1. Die bereitgestellten Dateien dienen der beispielhaften Darstellung bzw. als Unterst�tzung zur Validierung der FHIR-Instanzen einer eRezep.
2. Softwarehersteller m�ssen unbeachtet dieser Dateien sicherstellen, dass zur Validierung der FHIR-Instanzen im Feld immer die aktuellen FHIR-Ressourcen verwendet werden.

�nderungen der Version 1.1.0 vom 15.05.2023 zum Stand Version 1.1.0 vom 30.09.2022
- Im Profil KBV_PR_ERP_Bundle Constraint -erp-angabeFachgruppennummerAsvVerantwortlichePersonVerbot korrigiert
- In den Profilen KBV_PR_ERP_Medication_PZN, KBV_PR_ERP_Medication_Ingredient und KBV_PR_ERP_Medication_Compounding wurden der Constraint -erp-begrenzungValue entfernt
- Im Profil KBV_PR_ERP_Prescription wurde der Constraint -erp-begrenzungText angepasst (L�nge des Abgabehinweises auf 500 Zeichen korrigiert)
- Im Profil KBV_PR_ERP_Medication_Ingredient wurde die <path> Angabe beim Element "Medication.amount.numerator.extension:Packungsgroesse.value[x]:valueString" korrigiert
- In den Profilen KBV_PR_ERP_Medication_Ingredient und KBV_PR_ERP_Medication_Compounding wurde die Typisierung beim Element �Medication.ingredient.item[x]� konkret abgebildet

